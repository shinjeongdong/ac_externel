#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED


extern HANDLE hProc;


#endif // MAIN_H_INCLUDED