#include "hack.h"
#include <stdio.h>
BOOL hack::Aimbot()
{
    printf("������\n");
    return 0;
}

BOOL hack::ESP()
{
    return 0;
}
