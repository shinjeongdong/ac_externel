#include "Cheats.h"
#include "main.h"
#include "hack.h"
#include <stdio.h>


void Cheats::Run()
{
	local localentity;
	ReadProcessMemory(hProc, (LPCVOID)(0x400000 + 0x18AC00), (LPVOID)&localentity.player_base, sizeof(int), 0);
	
	for (int i = 0; i < 32; i++)
	{
		entity entity;
		localentity.GetPos();
		ReadProcessMemory(hProc, (LPCVOID)(0x400000 + 0x191fcc), (LPVOID)&entity.entity_base, sizeof(int), 0);
		ReadProcessMemory(hProc, (LPCVOID)(entity.entity_base +(i*4)), (LPVOID)&entity.entity_base, sizeof(int), 0);
		entity.GetPos();
		entity.GetHealth();
		entity.Getalive();
		
		
		if (!(entity.alive == 1) || entity.health <= 0 || entity.health > 100)
		{
			continue; 
		}

		printf("%d\n", entity.health);

		if (GetAsyncKeyState(VK_CONTROL) & 0x8000)
		{
			hack::Aimbot();
		}
	}
	
	return;
}
