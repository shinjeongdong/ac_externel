#pragma once
namespace GetProc
{
	DWORD GetProcId(const char* procName);
}


