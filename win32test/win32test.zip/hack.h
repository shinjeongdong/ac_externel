#pragma once
#include <windows.h>

namespace hack
{
	BOOL Aimbot();

	BOOL ESP();
	
}