#pragma once

#include "class.h"

namespace Cheats
{
	void Run();
}